package command;

public interface IComando {
    String execute();
}